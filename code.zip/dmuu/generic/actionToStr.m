function str = actionToStr(a)
% $Id: actionToStr.m,v 1.1 2005/02/09 16:46:09 mtjspaan Exp $

global problem

str=problem.actions(a,:);
