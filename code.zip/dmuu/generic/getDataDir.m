function directory = getDataDir
% getDataDir - specify the directory where data should be stored
%
% Returns a string, defaults to '.'

% $Id: getDataDir.m,v 1.4 2006/06/21 09:18:47 mtjspaan Exp $

directory='.';
