function initProblem
% Generic initProblem.m. Should be overwritten in problem directory if
% necessary.

% $Id: initProblem.m,v 1.1 2005/03/17 09:56:55 mtjspaan Exp $

clear global pomdp;
global problem;
global pomdp;

initPOMDP;
initProblemGeneric;
