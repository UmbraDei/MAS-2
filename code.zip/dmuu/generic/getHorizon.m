function h = getHorizon
% $Id: getHorizon.m,v 1.1 2005/02/09 16:46:09 mtjspaan Exp $

h=1000000;
