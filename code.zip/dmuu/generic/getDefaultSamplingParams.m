function [nrRewardStarts,maxSteps,nrRewardRuns] = ...
    getDefaultSamplingParams
% $Id: getDefaultSamplingParams.m,v 1.2 2005/02/15 14:29:40 mtjspaan Exp $

nrRewardStarts=10000;
maxSteps=1000;
nrRewardRuns=1;
