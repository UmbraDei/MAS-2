function S = getRandState
% $Id: getRandState.m,v 1.1 2005/02/15 13:09:48 mtjspaan Exp $

S{1}=rand('state');
S{2}=randn('state');
