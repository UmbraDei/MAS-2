function plotState(s)

plotMMDPstate(s);
