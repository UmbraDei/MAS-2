function terminalStates = getTerminalStates
% $Id: getTerminalStates.m,v 1.1 2003/12/04 17:01:35 mtjspaan Exp $

global problem;

terminalStates=[69:72];
