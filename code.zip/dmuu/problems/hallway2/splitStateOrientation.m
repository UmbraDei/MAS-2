function [s0,or] = splitStateOrientation(s)
% $Id: splitStateOrientation.m,v 1.1 2003/08/13 09:10:59 mtjspaan Exp $

[s0,or]=split(s,4);
