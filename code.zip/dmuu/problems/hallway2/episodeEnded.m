function bool = episodeEnded(r,s1)
% $Id: episodeEnded.m,v 1.1 2003/08/25 09:11:32 mtjspaan Exp $

if ismember(s1,[69:72])
  bool=0;
else
  bool=0;
end
