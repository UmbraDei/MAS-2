function bool = episodeEnded(r,s1)
% $Id: episodeEnded.m,v 1.1 2003/09/11 08:51:29 mtjspaan Exp $

if ismember(s1,[57:60])
  bool=0;
else
  bool=0;
end
