function T = getTerminalStates

T=getGoalState;

