addpath(strcat(pwd,'/yourcode_new'));
addpath(strcat(pwd,'/generic'));
addpath(strcat(pwd,'/yourcode_graphical_scripts'));
