cd('../hallway2');
'hallway2'
timing_vi;