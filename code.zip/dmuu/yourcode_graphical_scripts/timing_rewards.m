%%

cd('../hallway');
'hallway'
calculating_rewards;

cd('../hallway2');
'hallway2'
calculating_rewards;

cd('../trc');
'trc'
calculating_rewards;



%cd('../loadunload');
%'loadunload'
%calculating_rewards;

if 0
%%
cd('../isr');
'isr'
calculating_rewards_multiagent;


cd('../onedoor');
'onedoor'
calculating_rewards_multiagent;

cd('../mit');
'mit'
calculating_rewards_multiagent;
end
