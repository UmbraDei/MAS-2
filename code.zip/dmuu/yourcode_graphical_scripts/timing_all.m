%%
if 0
cd('../hallway');
'hallway'
timing_vi;

cd('../hallway2');
'hallway2'
timing_vi;

end 


cd('../trc');
'trc'
timing_vi;

if 0
cd('../loadunload');
'loadunload'
timing_vi;
end

if 0
%%
cd('../isr');
'isr'
timing_multiagents;


cd('../onedoor');
'onedoor'
timing_multiagents;
end

cd('../mit');
'mit'
timing_multiagents;

