%%
cd('../hallway');
'hallway'
plotFigures;

cd('../hallway2');
'hallway2'
plotFigures;

cd('../trc');
'trc'
plotFigures;