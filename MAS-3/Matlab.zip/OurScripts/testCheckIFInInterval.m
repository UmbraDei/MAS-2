% A script to check if the interval script is valid.
checkIfInInterval([1,2], [3,4])
checkIfInInterval([1,2], [-1,0])
checkIfInInterval([1,2], [0, 1.5])
checkIfInInterval([1,2], [1.5, 3])
checkIfInInterval([1,2], [1.1, 1.8])
checkIfInInterval([1,2], [0,3])
checkIfInInterval([1,2], [2,3])