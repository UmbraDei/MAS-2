% Create STN from the given input.
stn = opstellenSTN6a();
[oplossing, flex] = determineFlexFromSTN(stn);